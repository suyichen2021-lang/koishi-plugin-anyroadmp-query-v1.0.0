# AnyRoadMP query plugin 安装教程

本教程适用于 Koishi 4.x。插件包名：`koishi-plugin-anyroadmp-query`。

- 作者：苏一辰2021
- 联系方式：QQ 3336154936
- 官网：https://anyroadmp.com/

---

## 1. 环境要求

- Koishi 4.18 或更高版本
- Node.js 18 或更高版本（Koishi 自带运行时也可以）
- 可选：`koishi-plugin-puppeteer` + Chrome/Chromium（用于资料卡、签到、VTC、位置卡、帮助图）
- 建议服务器内存 2GB 以上（实时地图截图会启动无头浏览器）

没有 puppeteer 时插件仍可使用，所有图片会自动回退为文字。

---

## 2. 安装方式一：Koishi 插件市场

如果插件已经发布到 npm / Koishi 市场：

1. 打开 Koishi 控制台
2. 进入「插件市场」
3. 搜索 `anyroadmp-query`
4. 点击安装
5. 在「插件配置」中启用并填写配置
6. 重启 Koishi

---

## 3. 安装方式二：手动安装压缩包

### 3.1 找到 Koishi 实例目录

Koishi Desktop 一般在：

```text
koishi/data/instances/default/
```

该目录下应有：

```text
koishi.yml
package.json
node_modules/
data/
```

### 3.2 复制插件

解压压缩包，把整个 `koishi-plugin-anyroadmp-query` 文件夹放到：

```text
<实例目录>/node_modules/koishi-plugin-anyroadmp-query/
```

最终应存在：

```text
<实例目录>/node_modules/koishi-plugin-anyroadmp-query/package.json
<实例目录>/node_modules/koishi-plugin-anyroadmp-query/lib/index.js
```

### 3.3 启用插件

编辑实例目录下的 `koishi.yml`，在 `plugins:` 下加入：

```yaml
plugins:
  anyroadmp-query:anyroadmp:
    dataDir: data/anyroadmp-query
    image: true
    timeout: 15000
    maxLeaderboard: 20
    notify: true
    notifyInterval: 60
    notifyTargets: 'onebot:865683071'
```

说明：

- `anyroadmp-query` 是包名
- `anyroadmp` 是实例内的唯一后缀，可以改成其他字母数字
- 如果使用控制台配置，直接在插件列表里启用 `anyroadmp-query` 即可

### 3.4 重启 Koishi

Koishi Desktop：

```bash
cd <koishi 目录>
./koi restart default
```

或直接在控制台重启实例。

### 3.5 验证

启动日志出现类似：

```text
apply plugin anyroadmp-query:anyroadmp
```

即加载成功。

在聊天中发送：

```text
帮助
```

能收到功能图或文字帮助即安装完成。

---

## 4. 开启图片功能（推荐）

### 4.1 安装 puppeteer 插件

在 Koishi 控制台插件市场安装 `puppeteer`，或在 `package.json` 中加入：

```json
{
  "dependencies": {
    "koishi-plugin-puppeteer": "^3.9.0"
  }
}
```

然后执行 `yarn install`。

### 4.2 配置 Chrome

`koishi.yml` 示例：

```yaml
plugins:
  puppeteer:
    executablePath: /home/koishi/.cache/puppeteer/chrome/linux-158.0.8127.36/chrome-linux64/chrome
    args:
      - --no-sandbox
      - --disable-dev-shm-usage
      - --disable-gpu
  anyroadmp-query:anyroadmp:
    dataDir: data/anyroadmp-query
    image: true
```

Linux 服务器还需要安装 Chrome 运行库：

```bash
apt-get update
apt-get install -y libnspr4 libnss3 libatk1.0-0t64 libatk-bridge2.0-0t64 \
  libcups2t64 libdrm2 libxkbcommon0 libxcomposite1 libxdamage1 libxfixes3 \
  libxrandr2 libgbm1 libasound2t64 libpango-1.0-0 libcairo2 libx11-xcb1 \
  libxcb-dri3-0 fonts-noto-cjk fonts-noto-color-emoji
```

没有 Chrome 时，`image: true` 不会报错，插件会自动改为文字回复。

---

## 5. 配置项

| 配置项 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| `dataDir` | string | `data/anyroadmp-query` | 绑定、签到与通知订阅数据目录 |
| `image` | boolean | `true` | 有 puppeteer 时渲染图片，失败自动回退文字 |
| `timeout` | number | `15000` | 上游接口超时（毫秒） |
| `maxLeaderboard` | number | `20` | 排行榜显示人数 |
| `notify` | boolean | `true` | 是否启用服务器上下线通知 |
| `notifyInterval` | number | `60` | 状态轮询间隔（秒，最低 30） |
| `notifyTargets` | string | 空 | 额外通知目标，如 `onebot:865683071` |

---

## 6. 指令

| 指令 | 说明 |
| --- | --- |
| `签到` | 每日签到，记录连续/累计天数 |
| `绑定编号` | 绑定 AnyRoadMP 司机编号 |
| `查询` / `查询编号` | 查看玩家资料卡 |
| `我的位置` | 生成实时地图位置卡片 |
| `查VTC编号` | 查看 VTC 车队资料 |
| `服务器状态` | 查看 AnyRoadMP 服务器状态 |
| `订阅服务器通知` | 订阅当前群/私聊的上下线通知 |
| `取消服务器通知` | 取消当前会话的上下线通知 |
| `服务器通知` | 查看当前会话订阅状态 |
| `排行榜周` / `排行榜月` / `排行榜总` | 里程排行榜 |
| `解绑` | 解除绑定 |
| `帮助` | 功能帮助 |
| `全量消息` | 查看 QQ 群免 @ 的开启步骤 |

兼容：`AR绑定`、`AR状态`、`AR排行榜周`、`#查询`、`/查询`。

---

## 7. 数据与备份

```text
<实例目录>/data/anyroadmp-query/bindings.json        绑定数据
<实例目录>/data/anyroadmp-query/checkins.json        签到数据
<实例目录>/data/anyroadmp-query/notifications.json   通知订阅
```

备份时直接复制整个 `data/anyroadmp-query` 目录即可。

---

## 8. QQ 群免 @

QQ 群机器人默认只接收 @ 消息。需要群主在手机 QQ 中开启：

```text
群聊 → 机器人头像 → 设置 → 机器人管理
→ 机器人可获取的群聊消息范围 → 获取群内全部消息
```

该开关由 QQ 平台控制，插件无法代替开启。开启后直接发送「签到」「查询编号」即可。

---

## 9. 常见问题

### 9.1 查询提示未绑定

先发送：

```text
绑定编号
```

把「编号」换成你的 AnyRoadMP 司机编号，数字直接跟在后面，不需要空格。

### 9.2 图片不显示

检查：

1. 是否安装并启用了 `koishi-plugin-puppeteer`
2. `executablePath` 是否正确
3. Chrome 运行库是否安装
4. Koishi 日志是否有 puppeteer 启动错误

临时可设置 `image: false` 使用文字回复。

### 9.3 中文或 emoji 显示为方块

安装字体：

```bash
apt-get install -y fonts-noto-cjk fonts-noto-color-emoji
```

然后重启 Koishi。

### 9.4 我的位置很慢

「我的位置」需要打开 AnyRoadMP 实时地图并等待地图加载、搜索、跟随、截图，首次通常需要十几秒；同一玩家 30 秒内重复查询会使用缓存。

### 9.5 群里必须 @ 才能用

参考第 8 节，由群主开启「获取群内全部消息」。

---

## 10. 升级与卸载

升级：

1. 备份 `data/anyroadmp-query`
2. 用新版本覆盖 `node_modules/koishi-plugin-anyroadmp-query`
3. 重启 Koishi

卸载：

1. 从 `koishi.yml` 删除 `anyroadmp-query` 配置
2. 删除 `node_modules/koishi-plugin-anyroadmp-query`
3. 按需保留或删除 `data/anyroadmp-query`
4. 重启 Koishi

---

## 11. 作者与许可

- 作者：苏一辰2021
- QQ：3336154936
- 官网：https://anyroadmp.com/
- License：MIT

本插件为社区第三方插件，非 AnyRoadMP 官方产品。
